# @babel/plugin-syntax-flow

> Allow parsing of the flow syntax

See our website [@babel/plugin-syntax-flow](https://babeljs.io/docs/babel-plugin-syntax-flow) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-flow
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-flow --dev
```
