export const M = [-0.14861, 1.78277, -0.29227, -0.90649, 1.97294, 0];

export const degToRad = Math.PI / 180;
export const radToDeg = 180 / Math.PI;
