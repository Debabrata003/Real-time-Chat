export const bias = 0.00379307325527544933;
export const bias_cbrt = Math.cbrt(bias);
