export const k = Math.pow(29, 3) / Math.pow(3, 3);
export const e = Math.pow(6, 3) / Math.pow(29, 3);
