declare function dataViewByteLength(value: DataView): number;
declare function dataViewByteLength(value: unknown): never;

export = dataViewByteLength;