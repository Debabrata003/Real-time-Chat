declare module 'emoji-regex' {
  function emojiRegex(): RegExp;

  export = emojiRegex;
}
