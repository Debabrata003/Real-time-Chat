declare function _exports(input: string, options?: Record<string, boolean>): string;
export = _exports;
