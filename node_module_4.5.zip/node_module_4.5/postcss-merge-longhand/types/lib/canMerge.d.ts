declare const _exports: (props: import('postcss').Declaration[], includeCustomProps?: boolean) => boolean;
export = _exports;
