declare const _exports: (v: string) => string;
export = _exports;
