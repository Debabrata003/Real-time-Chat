declare function _exports(color: string, stop?: string | undefined): boolean;
export = _exports;
