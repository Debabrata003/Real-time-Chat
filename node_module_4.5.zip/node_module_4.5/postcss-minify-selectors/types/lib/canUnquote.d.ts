declare function _exports(value: string): boolean;
export = _exports;
