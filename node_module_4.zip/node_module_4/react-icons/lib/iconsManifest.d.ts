export interface IconManifestType {
  id: string;
  name: string;
  projectUrl: string;
  license: string;
  licenseUrl: string;
}
export declare const IconsManifest: IconManifestType[];
