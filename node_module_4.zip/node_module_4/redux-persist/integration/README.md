Proxy package to enable
```js
import { PersistGate } from 'redux-persist/integration/react'
```