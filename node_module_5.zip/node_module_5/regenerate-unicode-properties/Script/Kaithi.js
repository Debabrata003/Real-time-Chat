const set = require('regenerate')(0x110CD);
set.addRange(0x11080, 0x110C2);
exports.characters = set;
