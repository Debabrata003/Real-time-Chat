const set = require('regenerate')(0x16FE1);
set.addRange(0x1B170, 0x1B2FB);
exports.characters = set;
