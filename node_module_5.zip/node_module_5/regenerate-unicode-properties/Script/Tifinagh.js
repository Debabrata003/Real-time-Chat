const set = require('regenerate')(0x2D7F);
set.addRange(0x2D30, 0x2D67).addRange(0x2D6F, 0x2D70);
exports.characters = set;
