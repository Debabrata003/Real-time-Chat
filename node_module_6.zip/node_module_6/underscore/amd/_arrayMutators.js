define(['exports', './pop', './push', './reverse', './shift', './sort', './splice', './unshift'], function (exports, pop, push, reverse, shift, sort, splice, unshift) {



	exports.pop = pop;
	exports.push = push;
	exports.reverse = reverse;
	exports.shift = shift;
	exports.sort = sort;
	exports.splice = splice;
	exports.unshift = unshift;

	Object.defineProperty(exports, '__esModule', { value: true });

});
