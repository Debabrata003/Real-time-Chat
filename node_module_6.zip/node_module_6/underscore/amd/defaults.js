define(['./_createAssigner', './allKeys'], function (_createAssigner, allKeys) {

	// Fill in a given object with default properties.
	var defaults = _createAssigner(allKeys, true);

	return defaults;

});
