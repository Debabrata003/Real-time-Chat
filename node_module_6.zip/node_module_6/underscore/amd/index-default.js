define(['./mixin', './index'], function (mixin, index) {

	// Default Export

	// Add all of the Underscore functions to the wrapper object.
	var _ = mixin(index);
	// Legacy Node.js API.
	_._ = _;

	return _;

});
