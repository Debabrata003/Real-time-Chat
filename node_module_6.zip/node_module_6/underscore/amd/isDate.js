define(['./_tagTester'], function (_tagTester) {

	var isDate = _tagTester('Date');

	return isDate;

});
