define(['./_tagTester'], function (_tagTester) {

	var isWeakSet = _tagTester('WeakSet');

	return isWeakSet;

});
