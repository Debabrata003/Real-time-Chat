define(function () {

	// Predicate-generating function. Often useful outside of Underscore.
	function noop(){}

	return noop;

});
